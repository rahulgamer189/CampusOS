package com.example.facultyhub

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole { ADMIN, FACULTY, STUDENT }
enum class ContentType { HOMEWORK, ASSIGNMENT, PROJECT, ACTIVITY, NOTE, SYLLABUS, CLASS_TEST, EXAM }

data class User(val id: String, val name: String, val email: String, val role: UserRole, val program: String = "B.Tech Computer Science", val semester: String = "Semester 4")
data class AcademicItem(val id: String, val title: String, val subtitle: String, val due: String, val type: ContentType, val icon: String, val color: Long, val progress: Int = 0, val status: String = "Open")
data class DashboardMetric(val label: String, val value: String, val change: String)
data class Notice(val title: String, val detail: String, val time: String)

@Entity(tableName = "submissions")
data class SubmissionEntity(@PrimaryKey val id: String, val itemId: String, val studentId: String, val text: String, val fileName: String?, val status: String, val updatedAt: Long)

@Entity(tableName = "personal_documents")
data class PersonalDocumentEntity(@PrimaryKey val id: String, val studentId: String, val name: String, val type: String, val createdAt: Long)

@Entity(tableName = "cached_academic_items")
data class CachedAcademicItemEntity(@PrimaryKey val id: String, val studentId: String, val title: String, val subtitle: String, val due: String, val type: String, val icon: String, val color: Long, val progress: Int, val status: String)
