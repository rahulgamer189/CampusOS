package com.example.facultyhub

import android.content.Context
import androidx.room.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Dao
interface SubmissionDao {
    @Query("SELECT * FROM submissions WHERE studentId = :studentId") fun observe(studentId: String): Flow<List<SubmissionEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(item: SubmissionEntity)
}

@Dao
interface DocumentDao {
    @Query("SELECT * FROM personal_documents WHERE studentId = :studentId ORDER BY createdAt DESC") fun observe(studentId: String): Flow<List<PersonalDocumentEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: PersonalDocumentEntity)
    @Delete suspend fun delete(item: PersonalDocumentEntity)
}

@Database(entities = [SubmissionEntity::class, PersonalDocumentEntity::class, CachedAcademicItemEntity::class], version = 1)
abstract class FacultyHubDatabase : RoomDatabase() {
    abstract fun submissionDao(): SubmissionDao
    abstract fun documentDao(): DocumentDao
}

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton fun provideDb(@ApplicationContext context: Context): FacultyHubDatabase = Room.databaseBuilder(context, FacultyHubDatabase::class.java, "facultyhub.db").build()
    @Provides fun provideSubmissionDao(db: FacultyHubDatabase) = db.submissionDao()
    @Provides fun provideDocumentDao(db: FacultyHubDatabase) = db.documentDao()
}

@Singleton
class FacultyHubRepository @Inject constructor(private val submissionDao: SubmissionDao, private val documentDao: DocumentDao) {
    private val currentUser = MutableStateFlow(User("student-001", "Aarav Sharma", "aarav@university.edu", UserRole.STUDENT))
    val user: Flow<User> = currentUser
    val documents: Flow<List<PersonalDocumentEntity>> = documentDao.observe("student-001")
    val submissions: Flow<List<SubmissionEntity>> = submissionDao.observe("student-001")

    val academicItems = listOf(
        AcademicItem("hw-1", "Data Structures Lab", "Implement a balanced binary search tree", "Due tomorrow", ContentType.HOMEWORK, "assignment", 0xFF6C63FF, status = "In progress"),
        AcademicItem("as-1", "Operating Systems Case Study", "Process scheduling and deadlock analysis", "Due 18 Aug", ContentType.ASSIGNMENT, "description", 0xFF00A896, status = "Not started"),
        AcademicItem("pr-1", "Campus Navigation App", "Milestone 2 · UX prototype", "Due 25 Aug", ContentType.PROJECT, "rocket_launch", 0xFFFF8A65, progress = 68, status = "68% complete"),
        AcademicItem("act-1", "Guest Lecture: Responsible AI", "Auditorium A · Dr. Meera Joshi", "20 Aug · 11:00 AM", ContentType.ACTIVITY, "event", 0xFF42A5F5),
        AcademicItem("note-1", "Computer Networks", "Unit 3 · Routing protocols", "Updated today", ContentType.NOTE, "menu_book", 0xFFAB47BC),
        AcademicItem("test-1", "Mid-Semester Class Test", "Database Management Systems", "28 Aug · 10:00 AM", ContentType.CLASS_TEST, "quiz", 0xFFEF5350)
    )
    val notices = listOf(
        Notice("New notes uploaded", "Computer Networks · Unit 3", "2h ago"),
        Notice("Result published", "Operating Systems · 82/100", "Yesterday"),
        Notice("Submission feedback", "Data Structures Lab", "2d ago")
    )
    suspend fun saveSubmission(item: AcademicItem, text: String, fileName: String?) = submissionDao.upsert(SubmissionEntity(item.id + "-submission", item.id, "student-001", text, fileName, "Submitted", System.currentTimeMillis()))
    suspend fun addDocument(name: String, type: String) = documentDao.insert(PersonalDocumentEntity(name + System.currentTimeMillis(), "student-001", name, type, System.currentTimeMillis()))
    suspend fun removeDocument(document: PersonalDocumentEntity) = documentDao.delete(document)
    fun switchRole(role: UserRole) { currentUser.value = when(role) { UserRole.ADMIN -> User("admin-001", "Priya Nair", "admin@university.edu", role); UserRole.FACULTY -> User("faculty-001", "Dr. Kabir Mehta", "kabir@university.edu", role); UserRole.STUDENT -> User("student-001", "Aarav Sharma", "aarav@university.edu", role) } }
}
