package com.example.facultyhub

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val BrandLight = Color(0xFF5B52D6)
private val BrandDark = Color(0xFFBDB5FF)

@Composable
fun FacultyHubTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val colors = if (darkTheme) darkColorScheme(primary = BrandDark, secondary = Color(0xFF8FD8C8), tertiary = Color(0xFFFFB59D)) else lightColorScheme(primary = BrandLight, secondary = Color(0xFF008A72), tertiary = Color(0xFFD95F42), background = Color(0xFFF9F9FD))
    MaterialTheme(colorScheme = colors, typography = Typography(), content = content)
}
