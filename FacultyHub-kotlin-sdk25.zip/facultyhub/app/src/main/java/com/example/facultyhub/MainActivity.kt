package com.example.facultyhub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp class FacultyHubApplication : android.app.Application()

@HiltViewModel
class FacultyHubViewModel @Inject constructor(private val repository: FacultyHubRepository) : ViewModel() {
    val user = repository.user.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), User("student-001", "Aarav Sharma", "aarav@university.edu", UserRole.STUDENT))
    val documents = repository.documents.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val submissions = repository.submissions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val items get() = repository.academicItems
    val notices get() = repository.notices
    fun submit(item: AcademicItem, text: String) = viewModelScope.launch { repository.saveSubmission(item, text, null) }
    fun addDocument(name: String) = viewModelScope.launch { repository.addDocument(name, "PDF") }
    fun deleteDocument(doc: PersonalDocumentEntity) = viewModelScope.launch { repository.removeDocument(doc) }
    fun switchRole(role: UserRole) = repository.switchRole(role)
}

class MainActivity : ComponentActivity() {
    private val vm by viewModels<FacultyHubViewModel>()
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { FacultyHubApp(vm) } }
}

@Composable fun FacultyHubApp(vm: FacultyHubViewModel) {
    var dark by remember { mutableStateOf(false) }
    FacultyHubTheme(dark) { Surface(Modifier.fillMaxSize()) { AppShell(vm, dark) { dark = !dark } } }
}

@Composable fun AppShell(vm: FacultyHubViewModel, dark: Boolean, toggleTheme: () -> Unit) {
    val user by vm.user.collectAsStateWithLifecycle(); val documents by vm.documents.collectAsStateWithLifecycle(); val submissions by vm.submissions.collectAsStateWithLifecycle()
    var tab by remember { mutableStateOf(0) }; var selected by remember { mutableStateOf<AcademicItem?>(null) }; var showRole by remember { mutableStateOf(false) }
    val tabs = listOf("Home", "Academic Hub", "Calendar", "Profile")
    Scaffold(bottomBar = { NavigationBar { tabs.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i; selected = null }, icon = { Icon(if (i == 0) Icons.Default.Home else if (i == 1) Icons.Default.MenuBook else if (i == 2) Icons.Default.CalendarMonth else Icons.Default.Person, null) }, label = { Text(label) }) } } }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            TopBar(user, dark, toggleTheme) { showRole = true }
            when { selected != null -> DetailScreen(selected!!, submissions.any { it.itemId == selected!!.id }) { vm.submit(selected!!, it); selected = null }
                tab == 0 -> HomeScreen(user, vm.notices) { tab = 1 }
                tab == 1 -> HubScreen(vm.items, documents, user) { selected = it } { vm.addDocument(it) } { vm.deleteDocument(it) }
                tab == 2 -> CalendarScreen(vm.items)
                else -> ProfileScreen(user, documents) { vm.addDocument(it) } { vm.deleteDocument(it) }
            }
        }
    }
    if (showRole) RoleDialog(user.role, { vm.switchRole(it); showRole = false }, { showRole = false })
}

@Composable fun TopBar(user: User, dark: Boolean, toggle: () -> Unit, role: () -> Unit) { Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Good morning, ${user.name.substringBefore(' ')}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text("${user.program} · ${user.semester}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; IconButton(toggle) { Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme") }; AssistChip(onClick = role, label = { Text(user.role.name.lowercase().replaceFirstChar { it.uppercase() }) }, leadingIcon = { Icon(Icons.Default.SwapHoriz, null) }) } }

@Composable fun HomeScreen(user: User, notices: List<Notice>, openHub: () -> Unit) { LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) { item { Spacer(Modifier.height(4.dp)); Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { MetricCard("Attendance", "92%", "+4.2%", Modifier.weight(1f)); MetricCard("CGPA", "8.7", "+0.3", Modifier.weight(1f)) } }; item { Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF5B52D6)), shape = RoundedCornerShape(24.dp)) { Column(Modifier.padding(22.dp)) { Text("Your academic hub", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Everything you need to stay ahead this semester.", color = Color.White.copy(alpha = .82f), modifier = Modifier.padding(top = 6.dp)); Button(openHub, Modifier.padding(top = 18.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF4C43C6))) { Text("Explore hub") } } } }; item { Text("Recent updates", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }; items(notices) { NoticeRow(it) } } }

@Composable fun MetricCard(label: String, value: String, change: String, modifier: Modifier) { Card(modifier, shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium); Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text(change, color = Color(0xFF008A72), style = MaterialTheme.typography.labelSmall) } } }

@Composable fun NoticeRow(n: Notice) { ListItem(headlineContent = { Text(n.title, fontWeight = FontWeight.SemiBold) }, supportingContent = { Text(n.detail) }, trailingContent = { Text(n.time, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }, leadingContent = { Icon(Icons.Default.NotificationsNone, null, tint = MaterialTheme.colorScheme.primary) }) }

@Composable fun HubScreen(items: List<AcademicItem>, docs: List<PersonalDocumentEntity>, user: User, open: (AcademicItem) -> Unit, add: (String) -> Unit, delete: (PersonalDocumentEntity) -> Unit) { var query by remember { mutableStateOf("") }; var filter by remember { mutableStateOf<ContentType?>(null) }; var showAdd by remember { mutableStateOf(false) }; val filtered = items.filter { (query.isBlank() || it.title.contains(query, true) || it.subtitle.contains(query, true)) && (filter == null || it.type == filter) }; LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { item { Text("Academic Hub", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("Your semester, organized", color = MaterialTheme.colorScheme.onSurfaceVariant); OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(top = 14.dp), placeholder = { Text("Search homework, notes, exams...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true) }; item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) { FilterChip(filter == null, { filter = null }, { Text("All") }); ContentType.entries.take(5).forEach { t -> FilterChip(filter == t, { filter = if (filter == t) null else t }, { Text(t.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }) }) } } }; item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Upcoming & recent", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text("${filtered.size} items", color = MaterialTheme.colorScheme.onSurfaceVariant) } }; items(filtered, key = { it.id }) { AcademicCard(it) { open(it) } }; item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Private documents", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); IconButton({ showAdd = true }) { Icon(Icons.Default.Add, "Add document") } }; Text("Only you can view or manage these files.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall); docs.forEach { ListItem(headlineContent = { Text(it.name) }, supportingContent = { Text(it.type) }, trailingContent = { IconButton({ delete(it) }) { Icon(Icons.Default.DeleteOutline, "Delete") } }, leadingContent = { Icon(Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.primary) }) } } }; if (showAdd) AddDocumentDialog({ add(it); showAdd = false }, { showAdd = false }) }

@Composable fun AcademicCard(item: AcademicItem, click: () -> Unit) { Card(onClick = click, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(46.dp), shape = RoundedCornerShape(14.dp), color = Color(item.color).copy(alpha = .15f)) { Icon(Icons.Default.AutoStories, null, Modifier.padding(12.dp), tint = Color(item.color)) }; Column(Modifier.padding(start = 14.dp).weight(1f)) { Text(item.title, fontWeight = FontWeight.Bold); Text(item.subtitle, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(item.due, style = MaterialTheme.typography.labelMedium, color = Color(item.color), modifier = Modifier.padding(top = 5.dp)) }; if (item.progress > 0) { Text("${item.progress}%", fontWeight = FontWeight.Bold) } else { Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) } } } }

@Composable fun DetailScreen(item: AcademicItem, submitted: Boolean, submit: (String) -> Unit) { var text by remember { mutableStateOf("") }; LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) { item { Text(item.type.name.replace('_', ' '), color = Color(item.color), fontWeight = FontWeight.Bold); Text(item.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text(item.subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant) }; item { Card(shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) { Text("Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text("${item.due}\n\nThis space contains the full brief, learning outcomes, attached resources, and teacher instructions for this academic item.", modifier = Modifier.padding(top = 10.dp)) } } }; if (item.type in listOf(ContentType.HOMEWORK, ContentType.ASSIGNMENT, ContentType.PROJECT)) { item { Text("Your submission", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); if (submitted) { AssistChip({ }, label = { Text("Submitted successfully") }, leadingIcon = { Icon(Icons.Default.CheckCircle, null) }) } else { OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth().height(130.dp), placeholder = { Text("Add a note for your teacher...") }); Button({ submit(text) }, Modifier.fillMaxWidth().padding(top = 10.dp)) { Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(8.dp)); Text("Submit work") } } } } } }

@Composable fun CalendarScreen(items: List<AcademicItem>) { Column(Modifier.fillMaxSize().padding(20.dp)) { Text("Academic calendar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("August 2026", color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(20.dp)); items.forEach { ListItem(headlineContent = { Text(it.title, fontWeight = FontWeight.SemiBold) }, supportingContent = { Text(it.type.name.replace('_', ' ')) }, trailingContent = { Text(it.due, style = MaterialTheme.typography.labelMedium) }, leadingContent = { Icon(Icons.Default.Event, null, tint = Color(it.color)) }) } } }

@Composable fun ProfileScreen(user: User, docs: List<PersonalDocumentEntity>, add: (String) -> Unit, delete: (PersonalDocumentEntity) -> Unit) { Column(Modifier.fillMaxSize().padding(20.dp)) { Text("Profile", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(16.dp)); Card(shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(20.dp)) { Text(user.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text(user.email, color = MaterialTheme.colorScheme.onSurfaceVariant); Divider(Modifier.padding(vertical = 14.dp)); Text(user.program); Text(user.semester) } }; Spacer(Modifier.height(22.dp)); Text("Privacy & security", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text("Personal documents are scoped to your student account and are never visible to faculty or administrators.", Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) } }

@Composable fun RoleDialog(current: UserRole, select: (UserRole) -> Unit, close: () -> Unit) { AlertDialog(onDismissRequest = close, confirmButton = {}, title = { Text("Preview role") }, text = { Column { UserRole.entries.forEach { r -> TextButton({ select(r) }, Modifier.fillMaxWidth()) { Text(if (r == current) "✓ " else "  "); Text(r.name.lowercase().replaceFirstChar { it.uppercase() }) } } } }) }
@Composable fun AddDocumentDialog(add: (String) -> Unit, close: () -> Unit) { var name by remember { mutableStateOf("") }; AlertDialog(onDismissRequest = close, confirmButton = { Button({ if (name.isNotBlank()) add(name) }) { Text("Save") } }, dismissButton = { TextButton(close) { Text("Cancel") } }, title = { Text("Add private document") }, text = { OutlinedTextField(name, { name = it }, label = { Text("Document name") }, singleLine = true) }) }
